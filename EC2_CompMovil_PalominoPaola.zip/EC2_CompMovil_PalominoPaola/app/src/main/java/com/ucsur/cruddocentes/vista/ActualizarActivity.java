package com.ucsur.cruddocentes.vista;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.ucsur.cruddocentes.R;
import com.ucsur.cruddocentes.datos.DocenteDao;
import com.ucsur.cruddocentes.modelo.Docente;

public class ActualizarActivity extends AppCompatActivity {
    private TextInputLayout tilNombre, tilPaterno, tilMaterno, tilSueldo, tilHijos;
    private TextInputEditText txtNombre, txtPaterno, txtMaterno, txtSueldo, txtHijos;
    private TextView tvCodigo;
    private Spinner spSexo;
    private ArrayAdapter<CharSequence> adapterSexo;
    private DocenteDao dao;
    private int codigo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualizar);
        dao = new DocenteDao(this);

        tvCodigo = findViewById(R.id.tvCodigo);
        tilNombre = findViewById(R.id.tilNombre);   txtNombre = findViewById(R.id.txtNombre);
        tilPaterno = findViewById(R.id.tilPaterno); txtPaterno = findViewById(R.id.txtPaterno);
        tilMaterno = findViewById(R.id.tilMaterno); txtMaterno = findViewById(R.id.txtMaterno);
        tilSueldo = findViewById(R.id.tilSueldo);   txtSueldo = findViewById(R.id.txtSueldo);
        tilHijos = findViewById(R.id.tilHijos);     txtHijos = findViewById(R.id.txtHijos);
        spSexo = findViewById(R.id.spSexo);

        adapterSexo = ArrayAdapter.createFromResource(
                this, R.array.sexos, android.R.layout.simple_spinner_item);
        adapterSexo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSexo.setAdapter(adapterSexo);

        // 1) Leer el código que mandó MainActivity
        codigo = getIntent().getIntExtra("codigo", -1);

        // 2) Buscar el docente y llenar los campos
        Docente d = dao.buscar(codigo);
        if (d == null) {
            Toast.makeText(this, "Docente no encontrado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        cargarCampos(d);

        findViewById(R.id.btnActualizar).setOnClickListener(v -> actualizar());
        findViewById(R.id.btnEliminar).setOnClickListener(v -> confirmarEliminar());
        findViewById(R.id.btnRegresar).setOnClickListener(v -> finish());
    }

    private void cargarCampos(Docente d) {
        tvCodigo.setText("Código: " + d.getCodigo());
        txtNombre.setText(d.getNombre());
        txtPaterno.setText(d.getPaterno());
        txtMaterno.setText(d.getMaterno());
        txtSueldo.setText(String.valueOf(d.getSueldo()));
        txtHijos.setText(String.valueOf(d.getHijos()));
        int pos = adapterSexo.getPosition(d.getSexo());
        if (pos >= 0) spSexo.setSelection(pos);
    }

    private String texto(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private boolean validarObligatorio(TextInputLayout til, TextInputEditText txt) {
        if (texto(txt).isEmpty()) {
            til.setError("Campo obligatorio");
            return false;
        }
        til.setError(null);
        return true;
    }

    private boolean validarSueldo() {
        String s = texto(txtSueldo);
        if (s.isEmpty()) { tilSueldo.setError("Campo obligatorio"); return false; }
        try {
            if (Double.parseDouble(s) > 0) { tilSueldo.setError(null); return true; }
            tilSueldo.setError("Debe ser mayor que 0");
        } catch (NumberFormatException e) {
            tilSueldo.setError("Ingresa un número válido");
        }
        return false;
    }

    private boolean validarHijos() {
        String s = texto(txtHijos);
        if (s.isEmpty()) { tilHijos.setError("Campo obligatorio"); return false; }
        try {
            if (Integer.parseInt(s) >= 0) { tilHijos.setError(null); return true; }
            tilHijos.setError("No puede ser negativo");
        } catch (NumberFormatException e) {
            tilHijos.setError("Ingresa un número entero");
        }
        return false;
    }

    private boolean validar() {
        boolean ok = true;
        ok &= validarObligatorio(tilNombre, txtNombre);
        ok &= validarObligatorio(tilPaterno, txtPaterno);
        ok &= validarSueldo();
        ok &= validarHijos();
        return ok;
    }

    private void actualizar() {
        if (!validar()) return;
        Docente d = new Docente(codigo, texto(txtNombre), texto(txtPaterno), texto(txtMaterno),
                spSexo.getSelectedItem().toString(),
                Double.parseDouble(texto(txtSueldo)), Integer.parseInt(texto(txtHijos)));
        if (dao.actualizar(d) > 0) {
            Toast.makeText(this, "Docente actualizado", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmarEliminar() {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar docente")
                .setMessage("¿Seguro que deseas eliminar este registro?")
                .setPositiveButton("Sí", (dlg, w) -> {
                    if (dao.eliminar(codigo) > 0) {
                        Toast.makeText(this, "Docente eliminado", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}