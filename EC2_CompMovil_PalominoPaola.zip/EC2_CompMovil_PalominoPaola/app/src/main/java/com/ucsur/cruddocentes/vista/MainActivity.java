package com.ucsur.cruddocentes.vista;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ucsur.cruddocentes.R;
import com.ucsur.cruddocentes.adaptador.AdaptadorDocente;
import com.ucsur.cruddocentes.datos.DocenteDao;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private DocenteDao dao;
    private AdaptadorDocente adaptador;
    private EditText txtBuscar;
    private TextView tvResumen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dao = new DocenteDao(this);
        txtBuscar = findViewById(R.id.txtBuscar);
        tvResumen = findViewById(R.id.tvResumen);
        ListView lv = findViewById(R.id.lvDocentes);
        lv.setEmptyView(findViewById(R.id.tvVacio));

        adaptador = new AdaptadorDocente(this, dao.listar(null));
        lv.setAdapter(adaptador);

        findViewById(R.id.btnNuevo).setOnClickListener(v ->
                startActivity(new Intent(this, NuevoActivity.class)));
        findViewById(R.id.btnConsultar).setOnClickListener(v -> cargarLista());
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            Intent i = new Intent(this, ActualizarActivity.class);
            i.putExtra("codigo", (int) id);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {   // se recarga al volver de otra pantalla
        super.onResume();
        cargarLista();
    }

    private void cargarLista() {
        adaptador.actualizarLista(dao.listar(txtBuscar.getText().toString().trim()));
        double[] r = dao.resumen();
        tvResumen.setText(String.format(Locale.getDefault(),
                "Total: %d docentes · Sueldo promedio: S/ %.2f", (int) r[0], r[1]));
    }
}