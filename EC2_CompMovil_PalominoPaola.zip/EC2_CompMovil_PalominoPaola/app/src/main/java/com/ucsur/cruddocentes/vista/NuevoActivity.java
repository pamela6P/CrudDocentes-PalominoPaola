package com.ucsur.cruddocentes.vista;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.ucsur.cruddocentes.R;
import com.ucsur.cruddocentes.datos.DocenteDao;
import com.ucsur.cruddocentes.modelo.Docente;

public class NuevoActivity extends AppCompatActivity {
    private TextInputLayout tilNombre, tilPaterno, tilMaterno, tilSueldo, tilHijos;
    private TextInputEditText txtNombre, txtPaterno, txtMaterno, txtSueldo, txtHijos;
    private Spinner spSexo;
    private DocenteDao dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo);
        dao = new DocenteDao(this);

        tilNombre = findViewById(R.id.tilNombre);   txtNombre = findViewById(R.id.txtNombre);
        tilPaterno = findViewById(R.id.tilPaterno); txtPaterno = findViewById(R.id.txtPaterno);
        tilMaterno = findViewById(R.id.tilMaterno); txtMaterno = findViewById(R.id.txtMaterno);
        tilSueldo = findViewById(R.id.tilSueldo);   txtSueldo = findViewById(R.id.txtSueldo);
        tilHijos = findViewById(R.id.tilHijos);     txtHijos = findViewById(R.id.txtHijos);
        spSexo = findViewById(R.id.spSexo);

        ArrayAdapter<CharSequence> adapterSexo = ArrayAdapter.createFromResource(
                this, R.array.sexos, android.R.layout.simple_spinner_item);
        adapterSexo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSexo.setAdapter(adapterSexo);

        findViewById(R.id.btnGrabar).setOnClickListener(v -> grabar());
        findViewById(R.id.btnRegresar).setOnClickListener(v -> finish());
    }

    private String texto(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private boolean validarObligatorio(TextInputLayout til, TextInputEditText txt) {
        if (texto(txt).isEmpty()) {
            til.setError("Campo obligatorio");
            return false;
        }
        til.setError(null);
        return true;
    }

    private boolean validarSueldo() {
        String s = texto(txtSueldo);
        if (s.isEmpty()) { tilSueldo.setError("Campo obligatorio"); return false; }
        try {
            if (Double.parseDouble(s) > 0) { tilSueldo.setError(null); return true; }
            tilSueldo.setError("Debe ser mayor que 0");
        } catch (NumberFormatException e) {
            tilSueldo.setError("Ingresa un número válido");
        }
        return false;
    }

    private boolean validarHijos() {
        String s = texto(txtHijos);
        if (s.isEmpty()) { tilHijos.setError("Campo obligatorio"); return false; }
        try {
            if (Integer.parseInt(s) >= 0) { tilHijos.setError(null); return true; }
            tilHijos.setError("No puede ser negativo");
        } catch (NumberFormatException e) {
            tilHijos.setError("Ingresa un número entero");
        }
        return false;
    }

    private boolean validar() {
        boolean ok = true;
        ok &= validarObligatorio(tilNombre, txtNombre);
        ok &= validarObligatorio(tilPaterno, txtPaterno);
        ok &= validarSueldo();
        ok &= validarHijos();
        return ok;
    }

    private void grabar() {
        if (!validar()) return;
        Docente d = new Docente(0, texto(txtNombre), texto(txtPaterno), texto(txtMaterno),
                spSexo.getSelectedItem().toString(),
                Double.parseDouble(texto(txtSueldo)), Integer.parseInt(texto(txtHijos)));
        long id = dao.insertar(d);
        Toast.makeText(this, id > 0 ? "Docente registrado" : "Error al registrar",
                Toast.LENGTH_SHORT).show();
        if (id > 0) finish();
    }
}